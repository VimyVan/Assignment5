package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.mail.search.FromStringTerm;
import javax.mail.search.OrTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SubjectTerm;
/**
 * IMailService�ӿڵ�ʵ��
 * @author 2014302580130����Բ
 *
 */
public class MyEmail2014302580130 implements IMailService{
	private final transient Properties props = System.getProperties();
	private transient MailAuthenticator2014302580130 authenticator;
	private transient Session session;
/**
 * ��ʼ�����������е��ʼ�������
 */
	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.host", "smtp.163.com");
        props.put("mail.store.protocol", "pop3");
        props.put("mail.pop3.host", "pop3.163.com");
        authenticator = new MailAuthenticator2014302580130("15827553521@163.com", "************");
        session = Session.getInstance(props, authenticator);
		
	}
	/**
	 * ���͵����ʼ�
	 * @param recipient �ռ��������ַ
     * @param subject �ʼ�����
     * @param content �ʼ�����
	 */
	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO Auto-generated method stub
        final MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(authenticator.getUsername()));
        message.setRecipient(RecipientType.TO, new InternetAddress(recipient));
        message.setSubject(subject);
        message.setContent(content.toString(), "text/html;charset=utf-8");
        Transport.send(message);
	}
/**
 * ѯ�ʷ������Ƿ������ʼ�����
 */
	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		Store store = session.getStore();
        store.connect();
        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_WRITE);
        if(folder.getUnreadMessageCount()==0){return false;}
        else{return true;}
	}
/**
 * �����Զ��ظ������ݣ���ת��Ϊ�ַ���
 * @param sender - �Զ��ظ��ķ����������ַ
 * @param subject - �Զ��ظ�������
 */
	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		SearchTerm st=new OrTerm(new FromStringTerm(sender),new SubjectTerm(subject));
		Store store = session.getStore();
        store.connect();
        Folder folder = store.getFolder("inbox");
        folder.open(Folder.READ_ONLY);
		Message[] msgs=folder.search(st);
		 int mailCounts = msgs.length;
		 //System.out.println(mailCounts);
		 String content=null;
	        for(int i = 0; i < mailCounts; i++) {

	            content = msgs[i].getContent().toString();
		//return msgs.getSubject().toString();
	            }
	        return content;	
		// TODO Auto-generated method stub
		
	}

}
